const castButton = document.getElementById('cast-button');
const statusDisplay = document.getElementById('status');
const fish = document.getElementById('fish');
const lake = document.getElementById('lake');
const keySequenceDisplay = document.getElementById('key-sequence');
const scoreDisplay = document.getElementById('score');
const levelDisplay = document.getElementById('level');
const timerDisplay = document.getElementById('timer');
const highScoreDisplay = document.getElementById('high-score');

let fishing = false;
let sequence = [];
let userInput = [];
let isCatching = false;
let score = 0;
let highScore = 0; // Variable to track high score
let level = 1;
let timeLeft = 60; // Timer variable
let timerInterval;

// Function to start the fishing process
castButton.addEventListener('click', () => {
    if (fishing || isCatching) return;

    fishing = true;
    statusDisplay.textContent = "Casting the line...";
    fish.style.display = "none";
    timeLeft = 60; // Reset timer
    timerDisplay.textContent = `Time: ${timeLeft}`; // Display initial time
    startTimer(); // Start the timer

    // Randomize fish appearance after a delay
    setTimeout(() => {
        spawnFish();
    }, 1000); // Time to cast line
});

// Function to start the timer
function startTimer() {
    timerInterval = setInterval(() => {
        timeLeft--;
        timerDisplay.textContent = `Time: ${timeLeft}`; // Update the timer display

        if (timeLeft <= 0) {
            clearInterval(timerInterval);
            endGame();
        }
    }, 1000);
}

// Function to spawn a new fish
function spawnFish() {
    const randomX = Math.random() * (lake.clientWidth - 30); // Random position for the fish
    fish.style.transform = `translateX(${randomX}px)`;
    fish.style.display = "block";
    statusDisplay.textContent = "Press the arrow keys in order to catch the fish!";
    
    // Start the catching mini-game
    startCatchingGame();
}

// Function to start the catching game
function startCatchingGame() {
    isCatching = true;
    generateSequence();
    keySequenceDisplay.innerHTML = `Sequence: ${sequence.map(key => `<span class="arrow">${getArrowEmoji(key)}</span>`).join('')}`;
    userInput = [];
}

// Function to generate a new random arrow key sequence for each level
function generateSequence() {
    sequence = []; // Clear previous sequence
    const keys = ['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'];
    const sequenceLength = level + 2; // Increase the length of the sequence based on level
    for (let i = 0; i < sequenceLength; i++) {
        sequence.push(keys[Math.floor(Math.random() * keys.length)]); // Add a random key to the sequence
    }
}

// Function to get the arrow emoji representation
function getArrowEmoji(key) {
    switch (key) {
        case 'ArrowUp':
            return '⬆️'; // Up Arrow
        case 'ArrowDown':
            return '⬇️'; // Down Arrow
        case 'ArrowLeft':
            return '⬅️'; // Left Arrow
        case 'ArrowRight':
            return '➡️'; // Right Arrow
        default:
            return '';
    }
}

// Listening for key presses
document.addEventListener('keydown', (event) => {
    if (!isCatching) return;

    userInput.push(event.key);

    if (userInput.length === sequence.length) {
        checkSequence();
    }
});

// Function to check if the user input matches the sequence
function checkSequence() {
    if (JSON.stringify(userInput) === JSON.stringify(sequence)) {
        statusDisplay.textContent = "You caught the fish!";
        score++;
        scoreDisplay.textContent = `Score: ${score}`;

        // Level up system
        if (score % 5 === 0) {
            level++;
            levelDisplay.textContent = `Level: ${level}`;
            increaseDifficulty();
        }

        // Check for high score
        if (score > highScore) {
            highScore = score;
            highScoreDisplay.textContent = `High Score: ${highScore}`;
        }

        resetGame();
    } else {
        statusDisplay.textContent = "The fish escaped!";
        resetGame();
    }
}

// Function to increase the difficulty
function increaseDifficulty() {
    // This function can be used to adjust game settings for increased difficulty.
}

// Function to reset the game
function resetGame() {
    fishing = false;
    isCatching = false;
    fish.style.display = "none";
    
    // Check if the player caught a fish before resetting
    if (score > 0) {
        setTimeout(() => {
            spawnFish(); // Spawn another fish for continuous play
        }, 1000);
    } else {
        setTimeout(() => {
            statusDisplay.textContent = "Ready to fish!";
            keySequenceDisplay.textContent = "";
        }, 2000);
    }
}

// Function to end the game
function endGame() {
    isCatching = false;
    fishing = false;
    fish.style.display = "none";
    clearInterval(timerInterval);
    alert("Time's up! Try again."); // Show alert box
    resetGame(); // Reset game for a new attempt
}
