# The Fish game 

A Pen created on CodePen.io. Original URL: [https://codepen.io/elilpgel-the-sasster/pen/yLmEGeM](https://codepen.io/elilpgel-the-sasster/pen/yLmEGeM).

